/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tiket;

/**
 *
 * @author LENOVO
 */
public class PemesananTiket {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Koneksi.getKoneksi();
        new Login().setVisible(true); 
    }
    
   public static void oke(){
    new Home().setVisible(true);
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
