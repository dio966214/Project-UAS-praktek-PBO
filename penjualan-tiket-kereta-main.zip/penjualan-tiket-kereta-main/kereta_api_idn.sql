-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2024 at 08:12 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kereta_api_idn`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `confirm_pass` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `nama`, `username`, `password`, `confirm_pass`) VALUES
(2, 'admin', 'admin', 'admin', ''),
(11, 'yoo1', 'theoo', '12', '123'),
(20, 'rio', 'tayo', '123', '123'),
(21, 'theo', 'theo', '123', NULL),
(22, NULL, 'THEO', '123', '123'),
(23, 'yocuy', 'kintaku', '123', NULL),
(24, 'yoo', '123', '123', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `harga`
--

CREATE TABLE `harga` (
  `id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `harga` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `harga`
--

INSERT INTO `harga` (`id`, `status`, `kelas`, `harga`) VALUES
(1, 'dewasa', 'eksekutif', '80000'),
(2, 'anak', 'eksekutif', '50000'),
(3, 'dewasa', 'ekonomi', '55000'),
(4, 'anak', 'ekonomi', '35000');

-- --------------------------------------------------------

--
-- Table structure for table `penumpang`
--

CREATE TABLE `penumpang` (
  `id` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `awal` varchar(50) NOT NULL,
  `tujuan` varchar(50) NOT NULL,
  `berangkat` varchar(50) NOT NULL,
  `tiba` varchar(50) NOT NULL,
  `tanggal` varchar(50) NOT NULL,
  `kereta` varchar(50) NOT NULL,
  `gerbong` varchar(50) NOT NULL,
  `dewasa` varchar(50) NOT NULL,
  `anak` varchar(50) NOT NULL,
  `total` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `penumpang`
--

INSERT INTO `penumpang` (`id`, `nama`, `alamat`, `awal`, `tujuan`, `berangkat`, `tiba`, `tanggal`, `kereta`, `gerbong`, `dewasa`, `anak`, `total`) VALUES
('Antrean 1', 'ee', 'ee', 'MEDAN', 'Bandar Khalifah ', '07:00 WIB', '07:15 WIB', 'Tue Jan 09 10:01:06 ICT 2024', 'Commuter Line', 'Bisnis 1', '1', '1', 'Rp. 125000'),
('Antrean 2', '', '', 'MEDAN', 'Bandar Khalifah ', '00.00 WIB', '00.00 WIB', 'Tue Jan 09 13:56:48 ICT 2024', ' ', ' ', '0', '0', '0'),
('Antrean 3', '', '', 'MEDAN', 'Bandar Khalifah ', '00.00 WIB', '00.00 WIB', 'Tue Jan 09 13:59:18 ICT 2024', ' ', ' ', '0', '0', '0'),
('Antrean 4', 'z', 'jhkgk', 'MEDAN', 'Aras Kabu', '07:00 WIB', '07:30 WIB', 'Tue Jan 09 14:53:04 ICT 2024', 'Kereta Listrik', 'Ekonomi 1', '2', '0', 'Rp. 150000'),
('Antrean 5', 'qq', 'wwwqr', 'MEDAN', 'Batangtoru', '07:00 WIB', '08:00 WIB', 'Tue Jan 09 15:32:38 ICT 2024', 'Kereta Listrik', 'Bisnis 1', '1', '0', 'Rp. 75000'),
('Antrean 6', '', '', 'MEDAN', ' ', '00.00 WIB', '00.00 WIB', 'Tue Jan 09 15:51:01 ICT 2024', ' ', ' ', '0', '0', '0'),
('Antrean 7', '', '', 'MEDAN', ' ', '00.00 WIB', '00.00 WIB', 'Tue Jan 09 17:56:40 ICT 2024', ' ', ' ', '0', '0', '0'),
('Antrean 8', 'theo', 'tembung', 'MEDAN', 'Aras Kabu', '07:00 WIB', '07:30 WIB', 'Tue Jan 09 22:44:32 ICT 2024', 'Kereta Gojek', 'Bisnis 1', '1', '1', 'Rp. 130000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `harga`
--
ALTER TABLE `harga`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penumpang`
--
ALTER TABLE `penumpang`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `harga`
--
ALTER TABLE `harga`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
